
document.addEventListener("DOMContentLoaded", function() {
  const p = document.createElement('p');
  p.textContent = "JavaScript is working!";
  document.body.appendChild(p);
});
